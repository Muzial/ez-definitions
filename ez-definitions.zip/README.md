# ez-definitions
firefox extention~ double-click a word to display a popup with the definition

_inspired by:_
# [Dictionary Anywhere](https://github.com/meetDeveloper/Dictionary-Anywhere/)
The **Dictionary Anywhere** extension helps you stay focused on what you are reading by eliminating the need to search for meaning, 
Double-clicking any word will view its definition in a small pop-up bubble. 
Now you never have to leave what you are reading to search for the meaning of the words you don't yet know.

Extension is available for [Google Chrome](https://chrome.google.com/webstore/detail/dictionary-anywhere/hcepmnlphdfefjddkgkblcjkbpbpemac/) and [Mozilla Firefox](https://addons.mozilla.org/en-US/firefox/addon/dictionary-anyvhere).

##### Enjoy Reading Uninterrupted!!!

## Please check out and support his work.
